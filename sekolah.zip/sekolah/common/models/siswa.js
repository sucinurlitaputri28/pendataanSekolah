'use strict';

module.exports = function(Siswa) {

};
