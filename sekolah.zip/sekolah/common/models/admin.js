'use strict';

module.exports = function(Admin) {

};
