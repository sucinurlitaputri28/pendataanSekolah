'use strict';

module.exports = function(Kelas) {

};
