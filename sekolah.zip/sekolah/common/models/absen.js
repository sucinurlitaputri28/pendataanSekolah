'use strict';

module.exports = function(Absen) {

};
