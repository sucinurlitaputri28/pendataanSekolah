'use strict';

module.exports = function(Nilai) {

};
