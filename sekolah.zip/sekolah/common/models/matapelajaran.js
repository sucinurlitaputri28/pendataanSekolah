'use strict';

module.exports = function(Matapelajaran) {

};
